# SENTINEL-EDGE — everything in one place

This bundle contains:
- `sentinel-edge-repo.zip` — the full project (25 files)
- `STEPS.md` — this checklist (GitHub upload + Hugging Face download)

---

## 1. GitHub — finish uploading to StarNomad/sentinel-edge

Repo: https://github.com/StarNomad/sentinel-edge
(Public, already created. If the wave ever takes it down, the zip in this
bundle is your backup — the code is safe no matter what.)

### Root files
Upload page: `github.com/StarNomad/sentinel-edge/upload/main`
Pick: `LICENSE`, `README.md`, `requirements.txt`
(`.gitignore` is hidden on phone file pickers — skip it, it's optional.)
Tap **Commit changes**.

### Folders — repeat for EACH folder below
a. Open: `github.com/StarNomad/sentinel-edge/new/main/FOLDER`
   (replace FOLDER, e.g. `.../new/main/detector`)
b. File name: `.gitkeep` — type `x` in the editor — **Commit new file**
   (this creates the folder)
c. Open: `github.com/StarNomad/sentinel-edge/upload/main/FOLDER`
   Upload that folder's files — **Commit changes**

### Which files go in each folder
- `detector` : `__init__.py`, `detector.py`
- `pipeline` : `__init__.py`, `pipeline.py`
- `eventdb`  : `__init__.py`, `eventdb.py`
- `analyst`  : `__init__.py`, `analyst.py`, `ollama_adapter.py`
- `demo`     : `__init__.py`, `smoke.py`
- `docs`     : `architecture.md`, `measured-results.md`
- `tests`    : `test_sentinel.py`

### Verify
Open https://github.com/StarNomad/sentinel-edge — every folder and file
listed, page says Public.

---

## 2. Hugging Face — chi-bench handbook (do on the Dell)

Dataset: https://huggingface.co/datasets/actava/managed-care-operations-handbook
Access already granted to account `neo-eyes`. ~33 MB, ~1,290 files —
don't try this on the phone.

On the Dell, in PowerShell:

    git clone https://huggingface.co/datasets/actava/managed-care-operations-handbook

Username: `neo-eyes` — password: your Hugging Face token.
If it rejects you (401): mint a fresh token at
https://huggingface.co/settings/tokens with **Repositories: Read**
permission and use that as the password.

chi-bench expects it at: `data/skills/managed-care-operations-handbook/`

---

## 3. When the repo upload is done

Tell Hannah. She will:
1. Verify every file landed in the right folder,
2. Fix the deck's GitHub URL to `github.com/StarNomad/sentinel-edge`,
3. Rebuild the 20-page PDF.
